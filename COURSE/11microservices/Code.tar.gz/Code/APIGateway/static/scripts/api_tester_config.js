API_Tester_Config =[];
API_Tester_Config["GetStatus"] = {
			"key": "GetStatus",
			"url": "/getStatus",
			"method": "GET",
			"params": [],
			"post_data" : null
		};
